﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_11_Toes
{
    internal class Afdeling
    {
        public string Id { get; set; }

        public string Source { get; set; }


        public string FirstName { get; set; }


        public string LastName { get; set; }

        public string DateOfVisit { get; set; } 

        public string Message { get; set; }

        public int Row { get; set; }    

        public float ReviewScore { get; set; }


    }
}
