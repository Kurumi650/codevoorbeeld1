﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.Appointments;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using static System.Net.Mime.MediaTypeNames;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace H_11_Toes
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        internal Afdeling SelectedAfdeling { get; private set; }
       
        
         
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void CsvEl_Click(object sender, RoutedEventArgs e)
        {
            var picker = new FileOpenPicker();
            picker.SuggestedStartLocation = PickerLocationId.Downloads;
            picker.FileTypeFilter.Add(".csv");

            var file = await picker.PickSingleFileAsync();

            if (file == null)
            {
                TextEl.Text = "Geen geldig bestand gekozen! Kies een .cv bestand.";
                return;
            }


            using (var FileAccess = await file.OpenReadAsync())
            {
                using (var stream = FileAccess.AsStreamForRead())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        var csvReader = new CsvReader(reader, CultureInfo.InvariantCulture);
                        var complaints = csvReader.GetRecords<Afdeling>().ToList();
                        
                       
                        AfdelingEl.ItemsSource = complaints;
                
                        float sum = 0;

                        foreach (var afdeling in complaints)
                        {

                            sum += afdeling.ReviewScore;
                            

                            AntaalEl.Text = ($"{afdeling.Row}");
                        }

                        float average = sum / complaints.Count;
                       
                        
                        GemiddeldEl.Text = ($"  {average.ToString("0.0")}");
                       


                    }
                }
            }
        }

       

        private async void LockaEl_Click(object sender, RoutedEventArgs e)
        {
            await Launcher.LaunchFolderAsync(ApplicationData.Current.LocalFolder);

            var storageFolder = ApplicationData.Current.LocalFolder;



        }

        private async void afdelingKnopEl_Click(object sender, RoutedEventArgs e)
        {
            var afdeling = (string)selectpickEl.SelectedValue;


             var storageFolder = ApplicationData.Current.LocalFolder;
             var file = await storageFolder.CreateFileAsync($"Doorsturen_naar.{afdeling}txt",
                    CreationCollisionOption.OpenIfExists);

             await FileIO.WriteTextAsync(file, SelectedAfdeling.Id);


        }

        private async void opslaanKnopEl_Click(object sender, RoutedEventArgs e)
        {
            var afdeling2 = (string)selectpickEl.SelectedValue;


            var storageFolder = ApplicationData.Current.LocalFolder;
            var file = await storageFolder.CreateFileAsync($"Doorsturen_naar{afdeling2}_.txt",
                   CreationCollisionOption.OpenIfExists);
            
            await FileIO.WriteTextAsync(file, $"Klachtnummer: {SelectedAfdeling.Id}\n" +
              $"Naam: {SelectedAfdeling.FirstName} {SelectedAfdeling.LastName}\n" +
              $"-----------WERKBRIEF INSTRUCTIES---------\n" +
              $"{textEl.Text}\n" +
              $"-----------INGEDIENDE KLACHT-------------\n" +
              $"{ SelectedAfdeling.Message}");
             
        }

        private void AfdelingEl_ItemClick(object sender, ItemClickEventArgs e)
        {
            SelectedAfdeling = (Afdeling)e.ClickedItem;

            codeEl.Text = SelectedAfdeling.Id;
            
          
        }
    }
}
